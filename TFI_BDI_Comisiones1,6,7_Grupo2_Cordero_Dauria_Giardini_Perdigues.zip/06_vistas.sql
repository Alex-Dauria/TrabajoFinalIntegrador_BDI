USE `empresa`;

-- VISTA 1: Resumen ejecutivo de empleados activos por área
CREATE OR REPLACE VIEW vista_resumen_empleados_activos AS
SELECT 
    e.area,
    COUNT(*) as total_empleados,
    COUNT(l.id) as legajos_activos,
    ROUND(AVG(DATEDIFF(CURDATE(), e.fecha_ingreso)/365), 2) as antiguedad_promedio_años,
    MIN(e.fecha_ingreso) as fecha_ingreso_mas_antigua,
    MAX(e.fecha_ingreso) as fecha_ingreso_mas_reciente,
    GROUP_CONCAT(DISTINCT l.categoria ORDER BY l.categoria SEPARATOR ', ') as categorias_presentes
FROM empleados e
LEFT JOIN legajos l ON e.id = l.empleado_id AND l.estado = 'ACTIVO' AND l.eliminado = FALSE
WHERE e.eliminado = FALSE
GROUP BY e.area;

-- VISTA 2: Análisis temporal de altas y bajas
CREATE OR REPLACE VIEW vista_analisis_temporal AS
SELECT 
    YEAR(l.fecha_alta) as año,
    MONTH(l.fecha_alta) as mes,
    l.categoria,
    e.area,
    COUNT(*) as total_movimientos,
    COUNT(CASE WHEN l.estado = 'ACTIVO' THEN 1 END) as altas,
    COUNT(CASE WHEN l.estado = 'INACTIVO' THEN 1 END) as bajas,
    ROUND(COUNT(CASE WHEN l.estado = 'ACTIVO' THEN 1 END) * 100.0 / COUNT(*), 2) as porcentaje_activos
FROM legajos l
INNER JOIN empleados e ON l.empleado_id = e.id
WHERE l.fecha_alta >= '2020-01-01'
    AND l.eliminado = FALSE
    AND e.eliminado = FALSE
GROUP BY YEAR(l.fecha_alta), MONTH(l.fecha_alta), l.categoria, e.area;

-- Consulta de ejemplo usando las vistas
SELECT * FROM vista_resumen_empleados_activos WHERE total_empleados > 1000;
SELECT * FROM vista_analisis_temporal WHERE año = 2024 AND area = 'IT';