
USE `empresa`;

CREATE USER 'gerente_marketing'@'localhost' IDENTIFIED BY 'marketing131025';

CREATE OR REPLACE VIEW empleados_marketing AS
SELECT * FROM empleados
WHERE empleados.area = 'Marketing'
WITH CHECK OPTION;

CREATE OR REPLACE VIEW legajos_activos_marketing AS
SELECT empleados.nombre, empleados.apellido, legajos.id, empleados.area, legajos.nro_legajo, 
	legajos.categoria, legajos.fecha_alta, 
	legajos.observaciones, legajos.empleado_id
FROM empleados
INNER JOIN legajos ON empleados.id = legajos.empleado_id
WHERE legajos.estado = 'ACTIVO' AND empleados.area = 'Marketing';

GRANT SELECT ON empresa.empleados_marketing TO 'gerente_marketing'@'localhost';
GRANT UPDATE ON empresa.empleados_marketing TO 'gerente_marketing'@'localhost';
GRANT SELECT ON empresa.legajos_activos_marketing TO 'gerente_marketing'@'localhost';

SHOW GRANTS FOR 'gerente_marketing'@'localhost';
;


-- **** CONSULTA PARAMETRIZADA ****


DROP PROCEDURE IF EXISTS agregar_empleado;
DELIMITER $$

CREATE PROCEDURE agregar_empleado(
    IN p_nombre VARCHAR(50),
    IN p_apellido VARCHAR(50),
    IN p_dni VARCHAR(20),
    IN p_area VARCHAR(50),
    IN p_fecha_ingreso DATE
)
BEGIN
  
    IF p_nombre IS NULL OR TRIM(p_nombre) = '' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Nombre inválido';
    END IF;

    IF p_apellido IS NULL OR TRIM(p_apellido) = '' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Apellido inválido';
    END IF;

    IF p_fecha_ingreso IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Fecha inválida';
    END IF;

  
    INSERT INTO empleados (nombre, apellido, dni, area, fecha_ingreso)
    VALUES (p_nombre, p_apellido, p_dni, p_area, p_fecha_ingreso);
END$$

DELIMITER ;






