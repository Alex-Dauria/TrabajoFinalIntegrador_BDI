USE `empresa`;

-- ══════════════════════════════════════════════════════════════════════
-- CONSULTA 1: JOIN + GROUP BY + HAVING 
-- Empleados por área con estadísticas
-- ══════════════════════════════════════════════════════════════════════
-- UTILIDAD: Obtener un panorama general de la dotación de personal
-- por departamento, identificando áreas con mayor concentración
-- y analizando patrones de antigüedad y estado de legajos
-- ══════════════════════════════════════════════════════════════════════
SELECT 
    e.area,
    COUNT(*) as total_empleados,
    COUNT(l.id) as legajos_activos,
    AVG(DATEDIFF(CURDATE(), e.fecha_ingreso)) as antiguedad_promedio_dias,
    COUNT(CASE WHEN l.estado = 'INACTIVO' THEN 1 END) as legajos_inactivos
FROM empleados e
LEFT JOIN legajos l ON e.id = l.empleado_id
WHERE e.eliminado = FALSE
GROUP BY e.area
HAVING total_empleados > 1000 -- Enfocado en áreas significativas
ORDER BY total_empleados DESC;

-- ══════════════════════════════════════════════════════════════════════
-- CONSULTA 2: INNER JOIN + GROUP BY múltiple + funciones de fecha
-- Tendencias de contratación por año y categoría
-- ══════════════════════════════════════════════════════════════════════
-- UTILIDAD: Analizar cómo ha variado la contratación a lo largo
-- del tiempo en áreas estratégicas, permitiendo identificar
-- patrones estacionales y necesidades de planificación
-- ══════════════════════════════════════════════════════════════════════
SELECT 
    YEAR(l.fecha_alta) as año,
    l.categoria,
    COUNT(*) as total_legajos,
    COUNT(CASE WHEN l.estado = 'ACTIVO' THEN 1 END) as activos,
    COUNT(CASE WHEN l.estado = 'INACTIVO' THEN 1 END) as inactivos
FROM legajos l
INNER JOIN empleados e ON l.empleado_id = e.id
WHERE l.fecha_alta BETWEEN '2020-01-01' AND '2024-12-31'
    AND e.area IN ('IT', 'RRHH', 'Ventas') -- Áreas de alto impacto
    AND l.eliminado = FALSE
GROUP BY YEAR(l.fecha_alta), l.categoria
HAVING total_legajos > 50 -- Filtro de relevancia estadística
ORDER BY año DESC, total_legajos DESC;

-- ══════════════════════════════════════════════════════════════════════
-- CONSULTA 3: Subconsulta correlacionada + NOT EXISTS 
-- Empleados sin legajo activo
-- ══════════════════════════════════════════════════════════════════════
-- UTILIDAD: Identifica empleados que no tienen legajo activo vigente, 
-- lo cual puede indicar problemas administrativos, personal en proceso 
-- de baja o errores de carga
-- ══════════════════════════════════════════════════════════════════════
SELECT 
    e.id,
    e.nombre,
    e.apellido,
    e.area,
    e.fecha_ingreso
FROM empleados e
WHERE e.eliminado = FALSE
    AND NOT EXISTS (
        SELECT 1 
        FROM legajos l 
        WHERE l.empleado_id = e.id 
            AND l.estado = 'ACTIVO'
            AND l.eliminado = FALSE
    )
ORDER BY e.fecha_ingreso DESC
LIMIT 100; -- Muestra los casos más recientes primero

-- ══════════════════════════════════════════════════════════════════════
-- CONSULTA 4: JOIN + CASE + GROUP BY múltiple + HAVING
-- Clasificación de empleados por antigüedad
-- ══════════════════════════════════════════════════════════════════════
-- UTILIDAD: Segmentar la plantilla en rangos de experiencia
-- para facilitar análisis de retención
-- y detección de áreas con rotación alta o baja
-- ══════════════════════════════════════════════════════════════════════
SELECT 
    e.area,
    CASE 
        WHEN DATEDIFF(CURDATE(), e.fecha_ingreso) < 365 THEN 'Menos de 1 año'
        WHEN DATEDIFF(CURDATE(), e.fecha_ingreso) BETWEEN 365 AND 1825 THEN '1-5 años'
        WHEN DATEDIFF(CURDATE(), e.fecha_ingreso) > 1825 THEN 'Más de 5 años'
    END as rango_antiguedad,
    l.categoria,
    COUNT(*) as cantidad,
    ROUND(AVG(DATEDIFF(CURDATE(), e.fecha_ingreso)), 2) as antiguedad_promedio_dias
FROM empleados e
INNER JOIN legajos l ON e.id = l.empleado_id
WHERE e.eliminado = FALSE 
    AND l.eliminado = FALSE
    AND l.estado = 'ACTIVO' -- Solo empleados actualmente activos
GROUP BY e.area, rango_antiguedad, l.categoria
HAVING cantidad > 10 -- Grupos con representatividad suficiente
ORDER BY e.area, cantidad DESC;