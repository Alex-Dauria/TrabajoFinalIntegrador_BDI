USE `empresa`;

-- Primero obtenemos el máximo ID y LEGAJO para evitar duplicados
SET @max_empleado_id = (SELECT COALESCE(MAX(id), 0) FROM empleados);
SET @max_legajo_num = (SELECT COALESCE(MAX(CAST(SUBSTRING(nro_legajo, 5) AS UNSIGNED)), 0) FROM legajos);

-- Insertar 450.000 empleados
INSERT INTO empleados (nombre, apellido, dni, email, fecha_ingreso, area)
SELECT 
  CONCAT('Nombre_', LPAD(seq.num, 6, '0')),
  CONCAT('Apellido_', LPAD(seq.num, 6, '0')),
  LPAD(40000000 + @max_empleado_id + seq.num, 8, '0'),
  CONCAT('empleado', @max_empleado_id + seq.num, '@empresa.com'),
  DATE_ADD('2015-01-01', INTERVAL FLOOR(RAND() * 3650) DAY),
  ELT(FLOOR(1 + (RAND() * 5)), 'Ventas', 'RRHH', 'IT', 'Logística', 'Marketing')
FROM (
  SELECT 
    (a.n * 100000 + b.n * 10000 + c.n * 1000 + d.n * 100 + e.n * 10 + f.n) AS num
  FROM
    (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL
     SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL
     SELECT 8 UNION ALL SELECT 9) a
  CROSS JOIN
    (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL
     SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL
     SELECT 8 UNION ALL SELECT 9) b
  CROSS JOIN
    (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL
     SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL
     SELECT 8 UNION ALL SELECT 9) c
  CROSS JOIN
    (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL
     SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL
     SELECT 8 UNION ALL SELECT 9) d
  CROSS JOIN
    (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL
     SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL
     SELECT 8 UNION ALL SELECT 9) e
  CROSS JOIN
    (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL
     SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL
     SELECT 8 UNION ALL SELECT 9) f
) seq
WHERE seq.num BETWEEN 1 AND 450000;

-- Insertar legajos - ESPECIFICANDO EL ID EXPLÍCITAMENTE
SET @legajo_counter = @max_legajo_num;

INSERT INTO legajos (id, nro_legajo, categoria, estado, fecha_alta, observaciones, empleado_id)
SELECT 
  e.id,  -- Usamos el mismo ID del empleado
  CONCAT('LEG-', LPAD(@legajo_counter := @legajo_counter + 1, 6, '0')),
  ELT(FLOOR(1 + (RAND() * 4)), 'A', 'B', 'C', 'D'),
  ELT(FLOOR(1 + (RAND() * 2)), 'ACTIVO', 'INACTIVO'),
  DATE_ADD(e.fecha_ingreso, INTERVAL FLOOR(RAND() * 30) DAY), -- Usamos de referencia la de ingreso para que sea posterior
  CONCAT('Observaciones del empleado ', e.id),
  e.id
FROM empleados e
WHERE e.id > @max_empleado_id
ORDER BY e.id;

-- VERIFICACIONES --

-- Cantidad de empleados/legajos y FK huerfanas
SELECT 
  (SELECT COUNT(*) FROM empleados) AS total_empleados,
  (SELECT COUNT(*) FROM legajos) AS total_legajos,
  (SELECT COUNT(*) FROM legajos WHERE empleado_id NOT IN (SELECT id FROM empleados)) AS FK_huerfanas;
  
  
-- Porcentaje por área (verificar que la distribución aproxima lo planificado)
SELECT 
  area,
  COUNT(*) AS cantidad,
  ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM empleados), 2) AS porcentaje
FROM empleados
GROUP BY area
ORDER BY porcentaje DESC;

-- Fechas coherentes (debe dar 0)
SELECT COUNT(*) AS legajos_con_fecha_alta_menor
FROM legajos l
JOIN empleados e ON l.empleado_id = e.id
WHERE l.fecha_alta < e.fecha_ingreso;