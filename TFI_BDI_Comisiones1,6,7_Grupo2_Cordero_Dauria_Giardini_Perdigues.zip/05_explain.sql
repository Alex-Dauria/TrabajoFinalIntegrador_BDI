USE `empresa`;

-- MEDICIÓN 1: Consulta de IGUALDAD
-- Con índice
EXPLAIN ANALYZE
SELECT COUNT(*) 
FROM empleados FORCE INDEX (idx_empleados_area)
WHERE area = 'IT' 
AND eliminado = FALSE;

-- Sin índice (forzando a ignorar el índice)
EXPLAIN ANALYZE
SELECT COUNT(*) 
FROM empleados IGNORE INDEX (
    idx_empleados_area, 
    idx_empleados_fecha_ingreso, 
    idx_empleados_area_fecha
)
WHERE area = 'IT' 
AND eliminado = FALSE;

-- MEDICIÓN 2: Consulta de RANGO
-- Con índice
EXPLAIN ANALYZE
SELECT COUNT(*)
FROM legajos FORCE INDEX (idx_legajos_estado_fecha) 
WHERE fecha_alta BETWEEN '2023-01-01' AND '2024-12-31'
AND estado = 'ACTIVO';

-- Sin índice
EXPLAIN ANALYZE
SELECT COUNT(*)
FROM legajos IGNORE INDEX (
    idx_legajos_estado,
    idx_legajos_categoria,
    idx_legajos_fecha_alta,
    idx_legajos_estado_fecha
)
WHERE fecha_alta BETWEEN '2023-01-01' AND '2024-12-31'
AND estado = 'ACTIVO';

-- MEDICIÓN 3: Consulta con JOIN
-- Con índice
EXPLAIN ANALYZE
SELECT e.area, COUNT(*) as total
FROM empleados e
INNER JOIN legajos l
  ON e.id = l.empleado_id
WHERE e.fecha_ingreso > '2020-01-01'
AND l.estado = 'ACTIVO'
GROUP BY e.area;

-- Sin índice
EXPLAIN ANALYZE
SELECT e.area, COUNT(*) as total
FROM empleados e IGNORE INDEX (
    idx_empleados_area, 
    idx_empleados_fecha_ingreso, 
    idx_empleados_area_fecha
)

INNER JOIN legajos l IGNORE INDEX (
    idx_legajos_estado,
    idx_legajos_categoria,
    idx_legajos_fecha_alta,
    idx_legajos_estado_fecha
)
ON e.id = l.empleado_id
WHERE e.fecha_ingreso > '2020-01-01'
AND l.estado = 'ACTIVO'
GROUP BY e.area;