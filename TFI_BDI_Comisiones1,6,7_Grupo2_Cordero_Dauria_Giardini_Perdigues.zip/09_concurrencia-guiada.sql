/* ------------------------------------------------------------
  09_concurrencia_guiada.sql
  Trabajo Final Integrador – Bases de Datos I
  Comisión X | Grupo 2 | Cordero – Dauria – Giardini – Perdigues
  Tema: Gestión de empleados – Pruebas de concurrencia
-------------------------------------------------------------*/

USE empresa;

-- ============================================================
-- BLOQUEO Y TIMEOUT ENTRE SESIONES
-- ============================================================
-- Usuario 1 (gerente_marketing)
START TRANSACTION;
UPDATE empleados_marketing
SET email = 'rodriVallarta@hotmail.com'
WHERE id = 8;
-- Mantener transacción abierta (no hacer COMMIT)

-- Usuario 2 (gerente_rrhh)
START TRANSACTION;
UPDATE empleados
SET email = 'rodriVallarta@hotmail12.com'
WHERE id = 8;
-- Resultado esperado:
-- Error Code: 1205. Lock wait timeout exceeded; try restarting transaction


-- ============================================================
-- 2️ NIVEL DE AISLAMIENTO: READ COMMITTED
-- ============================================================

-- Usuario: gerente_rrhh (Sesión 1)
USE empresa;
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT email FROM empleados WHERE id = 44;

-- Usuario: gerente_marketing (Sesión 2)
USE empresa;
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
UPDATE empleados_marketing
SET email = 'caroTeran@gmail.com'
WHERE id = 44;
COMMIT;

-- Regresa a la Sesión 1
SELECT email FROM empleados WHERE id = 44;
COMMIT;
-- Se observa el nuevo valor confirmado, porque READ COMMITTED
-- permite lecturas no repetibles.


-- ============================================================
-- 3️ NIVEL DE AISLAMIENTO: REPEATABLE READ
-- ============================================================

-- Usuario: gerente_rrhh (Sesión 1)
USE empresa;
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
START TRANSACTION;
SELECT email FROM empleados WHERE id = 17;

-- Usuario: gerente_marketing (Sesión 2)
USE empresa;
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
START TRANSACTION;
UPDATE empleados_marketing
SET email = 'carolinaArratiaga@gmail.com'
WHERE id = 17;
COMMIT;

-- Regresa a la Sesión 1
SELECT email FROM empleados WHERE id = 17;
COMMIT;
-- Se mantiene el valor original, porque REPEATABLE READ
-- conserva la “foto” inicial de la transacción.


-- ============================================================
-- 4️ CONCURRENCIA E ÍNDICES
-- ============================================================

-- Usuario: gerente_rrhh
USE empresa;
SET SQL_SAFE_UPDATES = 0;
SET SESSION innodb_lock_wait_timeout = 10;
START TRANSACTION;
SELECT * FROM empleados WHERE area = 'RRHH' FOR UPDATE;
-- Mantener abierta la transacción

-- Usuario: gerente_marketing
USE empresa;
SET SQL_SAFE_UPDATES = 0;
SET SESSION innodb_lock_wait_timeout = 10;
START TRANSACTION;
SELECT * FROM empleados_marketing WHERE area = 'Marketing' FOR UPDATE;
-- Error Code: 1205. Lock wait timeout exceeded; try restarting transaction

-- Creación del índice para mejorar la concurrencia
USE empresa;
CREATE INDEX indx_area ON empleados(area);

-- Repetir las mismas consultas anteriores:
-- Ahora ambas transacciones pueden ejecutarse sin bloqueo entre sí.


-- ============================================================
-- 5️ DEADLOCK ENTRE TRANSACCIONES
-- ============================================================

-- Usuario: gerente_marketing (Sesión 1)
USE empresa;
SET SQL_SAFE_UPDATES = 0;
SET SESSION innodb_lock_wait_timeout = 10;
START TRANSACTION;
SELECT * FROM empleados_marketing WHERE id = 60 FOR UPDATE;

-- Usuario: gerente_rrhh (Sesión 2)
USE empresa;
SET SQL_SAFE_UPDATES = 0;
SET SESSION innodb_lock_wait_timeout = 10;
START TRANSACTION;
SELECT * FROM empleados WHERE id = 62 FOR UPDATE;

-- Cruce de bloqueos:
-- En Sesión 1:
SELECT * FROM empleados_marketing WHERE id = 62 FOR UPDATE;
-- En Sesión 2:
SELECT * FROM empleados WHERE id = 60 FOR UPDATE;

-- Resultado:
-- Error Code: 1213. Deadlock found when trying to get lock; try restarting transaction


-- ============================================================
-- 6️ PROCEDIMIENTO CON REINTENTO AUTOMÁTICO (RETRY)
-- ============================================================

DELIMITER $$

DROP PROCEDURE IF EXISTS actualizar_area_segura $$
CREATE PROCEDURE actualizar_area_segura (
    IN p_id BIGINT,
    IN p_nueva_area VARCHAR(50)
)
BEGIN
    DECLARE reintentos INT DEFAULT 0;
    DECLARE hecho BOOLEAN DEFAULT FALSE;

    -- Si ocurre un deadlock (Error 1213), incrementa el contador y espera 2 segundos
    DECLARE CONTINUE HANDLER FOR 1213
    BEGIN
        SET reintentos = reintentos + 1;
        DO SLEEP(2);
    END;

    WHILE (hecho = FALSE AND reintentos <= 2) DO
        START TRANSACTION;
        UPDATE empleados
        SET area = p_nueva_area
        WHERE id = p_id;
        COMMIT;
        SET hecho = TRUE;
    END WHILE;

    IF hecho THEN
        SELECT CONCAT('Transacción completada en intento ', reintentos + 1) AS resultado;
    ELSE
        ROLLBACK;
        SELECT 'Transacción abortada tras 2 reintentos' AS resultado;
    END IF;
END $$
DELIMITER ;

-- Sesión 1 (mantiene bloqueo)
START TRANSACTION;
UPDATE empleados
SET area = 'Bloqueado_por_RRHH'
WHERE id = 1;

-- Sesión 2 (ejecuta el procedimiento con retry)
CALL actualizar_area_segura(1, 'RRHH_final');
-- Resultado esperado:
-- "Transacción completada en intento 2"
