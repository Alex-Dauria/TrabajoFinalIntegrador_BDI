
USE empresa;

CREATE USER 'gerente_rrhh'@'localhost' IDENTIFIED BY 'rrhh131025';

GRANT SELECT ON empleados TO 'gerente_rrhh'@'localhost';
GRANT UPDATE ON empleados TO 'gerente_rrhh'@'localhost'; 
GRANT SELECT ON empleados_marketing TO 'gerente_rrhh'@'localhost';

CREATE INDEX indx_area ON empleados (area);



GRANT EXECUTE ON PROCEDURE empresa.retry_deadlock_1 TO 'gerente_marketing'@'localhost';
GRANT EXECUTE ON PROCEDURE empresa.retry_deadlock_2 TO 'gerente_rrhh'@'localhost';


DELIMITER $$

CREATE PROCEDURE retry_deadlock_1() -- usado por gerente_marketing
BEGIN
    DECLARE retry_count INT DEFAULT 0;
    DECLARE finished INT DEFAULT 0;  
    DECLARE CONTINUE HANDLER FOR 1213
    BEGIN
        ROLLBACK;
        SET retry_count = retry_count + 1;
        IF retry_count <= 2 THEN
            DO SLEEP(10); 
        ELSE
            SET finished = 1;
        END IF;
    END;

    REPEAT
        START TRANSACTION;

     
        SELECT * 
        FROM empleados_marketing 
        WHERE id = 62
        FOR UPDATE;

        DO SLEEP(5); 
        SELECT * 
        FROM empleados_marketing 
        WHERE id = 60
        FOR UPDATE;

        COMMIT;
        SET finished = 1;

    UNTIL finished = 1 OR retry_count > 2
    END REPEAT;

    IF finished = 0 THEN
        SELECT 'No se pudo completar la transacción después de 2 reintentos' AS mensaje;
    ELSE
        SELECT 'Transacción completada exitosamente' AS mensaje;
    END IF;
END

DELIMITER ;


DELIMITER $$

CREATE PROCEDURE retry_deadlock_2() -- usado por gerente_rrhh
BEGIN
    DECLARE retry_count INT DEFAULT 0;
    DECLARE finished INT DEFAULT 0;  
    DECLARE CONTINUE HANDLER FOR 1213
    BEGIN
        ROLLBACK;
        SET retry_count = retry_count + 1;
        IF retry_count <= 2 THEN
            DO SLEEP(5); 
        ELSE
            SET finished = 1;
        END IF;
    END;

    REPEAT
        START TRANSACTION;

     
        SELECT * 
        FROM empleados_marketing 
        WHERE id = 62
        FOR UPDATE;

        DO SLEEP(5); 
        SELECT * 
        FROM empleados_marketing 
        WHERE id = 60
        FOR UPDATE;

        COMMIT;
        SET finished = 1;

    UNTIL finished = 1 OR retry_count > 2
    END REPEAT;

    IF finished = 0 THEN
        SELECT 'No se pudo completar la transacción después de 2 reintentos' AS mensaje;
    ELSE
        SELECT 'Transacción completada exitosamente' AS mensaje;
    END IF;
END$$

DELIMITER ;