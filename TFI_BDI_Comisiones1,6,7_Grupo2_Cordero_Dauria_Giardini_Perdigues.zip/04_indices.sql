USE empresa;

-- Procedimiento para crear índices con manejo de errores
DELIMITER $$

CREATE PROCEDURE CrearIndicesConContinueHandler()
BEGIN
    -- Declarar un manejador que continúe ante errores de índice duplicado (código 1061)
    DECLARE CONTINUE HANDLER FOR 1061
    BEGIN
        -- No hacer nada, simplemente continuar
    END;
    
    -- Índices para consultas de igualdad
    CREATE INDEX idx_empleados_area ON empleados(area);
    CREATE INDEX idx_legajos_estado ON legajos(estado);
    CREATE INDEX idx_legajos_categoria ON legajos(categoria);
    
    -- Índices para consultas de rango
    CREATE INDEX idx_empleados_fecha_ingreso ON empleados(fecha_ingreso);
    CREATE INDEX idx_legajos_fecha_alta ON legajos(fecha_alta);
    
    -- Índices compuestos para JOINs y consultas complejas
    CREATE INDEX idx_empleados_area_fecha ON empleados(area, fecha_ingreso);
    CREATE INDEX idx_legajos_estado_fecha ON legajos(estado, fecha_alta);
END$$

DELIMITER ;

-- Ejecutar el procedimiento
CALL CrearIndicesConContinueHandler();

-- Eliminar el procedimiento
DROP PROCEDURE CrearIndicesConContinueHandler;

-- VERIFICACIÓN: Confirmar que los índices existen
SELECT 
    TABLE_NAME,
    INDEX_NAME,
    GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS COLUMNAS,
    INDEX_TYPE
FROM information_schema.STATISTICS
WHERE TABLE_SCHEMA = 'empresa'
    AND TABLE_NAME IN ('empleados', 'legajos')
    AND INDEX_NAME LIKE 'idx_%'
GROUP BY TABLE_NAME, INDEX_NAME, INDEX_TYPE
ORDER BY TABLE_NAME, INDEX_NAME;